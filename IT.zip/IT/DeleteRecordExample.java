import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteRecordExample {

    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/your_database_name"; // Replace with your database URL
        String username = "your_username";
        String password = "your_password";

        // SQL statement to delete a record
        String deleteRecordSQL = "DELETE FROM example_table WHERE id = ?";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create a PreparedStatement object
            PreparedStatement preparedStatement = connection.prepareStatement(deleteRecordSQL);

            // Set parameter for the delete statement
            preparedStatement.setInt(1, 1); // Replace with the ID of the record to delete

            // Execute the delete statement
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Record deleted successfully!");
            } else {
                System.out.println("No records were deleted.");
            }

            // Close the resources
            preparedStatement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
 
