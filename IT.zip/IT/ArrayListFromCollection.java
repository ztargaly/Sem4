import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListFromCollection {

    public static void main(String[] args) {
        // Create another collection (in this case, a List)
        List<String> originalList = Arrays.asList("Element 1", "Element 2", "Element 3");

        // Create an ArrayList from the existing collection
        ArrayList<String> arrayList = new ArrayList<>(originalList);

        // Displaying the elements in the ArrayList
        System.out.println("ArrayList elements:");
        for (String element : arrayList) {
            System.out.println(element);
        }
    }
}
