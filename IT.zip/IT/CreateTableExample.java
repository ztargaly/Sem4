import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableExample {

    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/your_database_name"; // Replace with your database URL
        String username = "your_username";
        String password = "your_password";

        // SQL statement to create a table
        String createTableSQL = "CREATE TABLE example_table (id INT PRIMARY KEY, name VARCHAR(255))";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create a Statement object
            Statement statement = connection.createStatement();

            // Execute the SQL statement to create the table
            statement.executeUpdate(createTableSQL);

            System.out.println("Table created successfully!");

            // Close the resources
            statement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
