import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PositiveNegativeChecker {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Positive/Negative Checker");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel);

        JLabel label = new JLabel("Enter an integer:");
        panel.add(label);

        JTextField textField = new JTextField(10);
        panel.add(textField);

        JButton checkButton = new JButton("Check");
        panel.add(checkButton);

        JLabel resultLabel = new JLabel();
        panel.add(resultLabel);

        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the integer from the text field
                    int number = Integer.parseInt(textField.getText());

                    // Check if the integer is positive or negative
                    if (number > 0) {
                        resultLabel.setText("Positive");
                    } else if (number < 0) {
                        resultLabel.setText("Negative");
                    } else {
                        resultLabel.setText("Zero");
                    }
                } catch (NumberFormatException ex) {
                    // Handle the case where the input is not a valid integer
                    resultLabel.setText("Invalid Input");
                }
            }
        });

        frame.setSize(300, 150);
        frame.setVisible(true);
    }
}
