import java.util.ArrayList;

public class RemoveElementsFromArrayList {

    public static void main(String[] args) {
        // Create an ArrayList of Strings
        ArrayList<String> arrayList = new ArrayList<>();

        // Adding elements to the ArrayList
        arrayList.add("Element 1");
        arrayList.add("Element 2");
        arrayList.add("Element 3");

        // Displaying the elements in the ArrayList before removal
        System.out.println("ArrayList elements before removal:");
        for (String element : arrayList) {
            System.out.println(element);
        }

        // Removing an element at index 1
        arrayList.remove(1);

        // Removing a specific element ("Element 3")
        arrayList.remove("Element 3");

        // Displaying the elements in the ArrayList after removal
        System.out.println("\nArrayList elements after removal:");
        for (String element : arrayList) {
            System.out.println(element);
        }
    }
}
