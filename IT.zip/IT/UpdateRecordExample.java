import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateRecordExample {

    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/your_database_name"; // Replace with your database URL
        String username = "your_username";
        String password = "your_password";

        // SQL statement to update a record
        String updateRecordSQL = "UPDATE example_table SET name = ? WHERE id = ?";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create a PreparedStatement object
            PreparedStatement preparedStatement = connection.prepareStatement(updateRecordSQL);

            // Set parameters for the update statement
            preparedStatement.setString(1, "NewName"); // Replace with the new name
            preparedStatement.setInt(2, 1); // Replace with the ID of the record to update

            // Execute the update statement
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Record updated successfully!");
            } else {
                System.out.println("No records were updated.");
            }

            // Close the resources
            preparedStatement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
