import java.util.ArrayList;
import java.util.List;

public class ExtractPortionOfArrayList {

    public static void main(String[] args) {
        // Create an ArrayList of Strings
        ArrayList<String> arrayList = new ArrayList<>();

        // Adding elements to the ArrayList
        arrayList.add("Element 1");
        arrayList.add("Element 2");
        arrayList.add("Element 3");
        arrayList.add("Element 4");
        arrayList.add("Element 5");

        // Displaying the elements in the ArrayList before extraction
        System.out.println("ArrayList elements before extraction:");
        for (String element : arrayList) {
            System.out.println(element);
        }

        // Extract a portion of the ArrayList (from index 1 to index 3)
        List<String> subList = arrayList.subList(1, 4);

        // Displaying the extracted portion of the ArrayList
        System.out.println("\nExtracted portion of ArrayList:");
        for (String element : subList) {
            System.out.println(element);
        }
    }
}
