import java.util.Arrays;

public class UpdateArrayElement {

    public static void main(String[] args) {
        // Create an array of integers
        int[] array = {1, 2, 3, 4, 5};

        // Displaying the elements in the array before update
        System.out.println("Array elements before update: " + Arrays.toString(array));

        // Update a specific element in the array (element at index 2)
        int indexToUpdate = 2;
        int newValue = 10;
        
        if (indexToUpdate >= 0 && indexToUpdate < array.length) {
            array[indexToUpdate] = newValue;
            System.out.println("Element at index " + indexToUpdate + " updated to " + newValue);
        } else {
            System.out.println("Invalid index for update.");
        }

        // Displaying the elements in the array after update
        System.out.println("Array elements after update: " + Arrays.toString(array));
    }
}
